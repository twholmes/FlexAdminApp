---------------------------------------------------------------------------
-- This sqlcmd script can be executed to configure data model
-- customisations for this FlexNet Manager Suite implementation.
--
-- Copyright (C) 2020 Crayon Australia
---------------------------------------------------------------------------

USE $(DBName)
GO

SET NOCOUNT ON
PRINT 'Remove report customizations'

GO
