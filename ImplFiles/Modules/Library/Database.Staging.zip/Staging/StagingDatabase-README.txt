This directory contains scripts that are used to configure a staging database.
This database is used where there is a need to stage and/or manipulate data before it 
is imported by an adapter.

Copyright (C) 2015 Flexera Software
