This directory contains adapters that are to be installed on a beacon. The
adapter XML files are stored in the BusinessAdapter folder, which is
installed by copying it to the
%ProgramData%\Flexera Software\Beacon\BusinessAdapter folder on the
beacon.

These adapters are typically triggered by the beacon scheduler. 

Copyright (C) 2020 Crayon Australia
